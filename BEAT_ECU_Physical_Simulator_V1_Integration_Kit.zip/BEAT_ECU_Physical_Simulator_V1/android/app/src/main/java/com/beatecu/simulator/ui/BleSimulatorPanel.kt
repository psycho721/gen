package com.beatecu.simulator.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.beatecu.simulator.ble.BeatEcuBleManager

@Composable
fun BleSimulatorPanel(
    bleManager: BeatEcuBleManager,
    modifier: Modifier = Modifier
) {
    val state by bleManager.connectionState.collectAsState()
    val telemetry by bleManager.telemetry.collectAsState()
    val device by bleManager.deviceName.collectAsState()

    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("PHYSICAL SIMULATOR", style = MaterialTheme.typography.titleMedium)
            Text("Status: $state")
            Text("Device: $device")
            Text("RPM: ${telemetry.rpm}")
            Text("Temperature: ${"%.1f".format(telemetry.temperatureC)} °C")
            Text("Battery: ${"%.2f".format(telemetry.batteryV)} V")
            Text("Throttle: ${"%.1f".format(telemetry.throttlePct)} %")
            Text("Fault: ${telemetry.faultCode} — ${telemetry.faultStatus}")
            Text("Sequence: ${telemetry.sequence}")
            Text(
                "SIMULATION ONLY",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelLarge
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { bleManager.startScan() }) {
                    Text("Connect")
                }
                OutlinedButton(onClick = { bleManager.disconnect() }) {
                    Text("Disconnect")
                }
            }
        }
    }
}
