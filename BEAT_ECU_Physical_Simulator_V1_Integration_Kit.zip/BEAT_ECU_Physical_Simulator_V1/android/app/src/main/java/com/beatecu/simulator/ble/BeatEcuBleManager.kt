package com.beatecu.simulator.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.BluetoothLeScanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID

data class BeatTelemetry(
    val rpm: Int = 0,
    val temperatureC: Double = 0.0,
    val batteryV: Double = 0.0,
    val throttlePct: Double = 0.0,
    val faultCode: String = "NONE",
    val faultStatus: String = "NORMAL",
    val sequence: Long = 0L,
    val simulationOnly: Boolean = true
)

class BeatEcuBleManager(context: Context) {
    private val appContext = context.applicationContext
    private val bluetoothManager =
        appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter?
        get() = bluetoothManager.adapter
    private val scanner: BluetoothLeScanner?
        get() = adapter?.bluetoothLeScanner

    private val _connectionState = MutableStateFlow("Disconnected")
    val connectionState: StateFlow<String> = _connectionState.asStateFlow()

    private val _telemetry = MutableStateFlow(BeatTelemetry())
    val telemetry: StateFlow<BeatTelemetry> = _telemetry.asStateFlow()

    private val _deviceName = MutableStateFlow("No device")
    val deviceName: StateFlow<String> = _deviceName.asStateFlow()

    private var gatt: BluetoothGatt? = null
    private var scanning = false

    private val serviceUuid = UUID.fromString(
        "7b6e0001-7d5a-4c2a-9f4b-2e8a00000001"
    )
    private val telemetryUuid = UUID.fromString(
        "7b6e0002-7d5a-4c2a-9f4b-2e8a00000001"
    )
    private val cccdUuid = UUID.fromString(
        "00002902-0000-1000-8000-00805f9b34fb"
    )

    private fun hasBlePermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return appContext.checkSelfPermission(
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
        return appContext.checkSelfPermission(
            android.Manifest.permission.BLUETOOTH_SCAN
        ) == PackageManager.PERMISSION_GRANTED &&
            appContext.checkSelfPermission(
                android.Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        if (!hasBlePermission()) {
            _connectionState.value = "Bluetooth permission required"
            return
        }
        val bleScanner = scanner
        if (bleScanner == null) {
            _connectionState.value = "Bluetooth unavailable or disabled"
            return
        }
        if (scanning) return

        _connectionState.value = "Searching for BEAT ECU simulator..."
        scanning = true
        bleScanner.startScan(scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        if (!hasBlePermission()) return
        if (scanning) scanner?.stopScan(scanCallback)
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName
            if (name == "BEAT_ECU_SIM_V1") {
                stopScan()
                connect(result.device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            _connectionState.value = "Scan failed ($errorCode)"
        }
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        if (!hasBlePermission()) return
        _deviceName.value = device.name ?: "BEAT_ECU_SIM_V1"
        _connectionState.value = "Connecting..."
        gatt?.close()
        gatt = device.connectGatt(appContext, false, gattCallback)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(
            bluetoothGatt: BluetoothGatt,
            status: Int,
            newState: Int
        ) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                _connectionState.value = "Connected; discovering service..."
                if (hasBlePermission()) bluetoothGatt.discoverServices()
            } else {
                _connectionState.value = "Disconnected"
                _deviceName.value = "No device"
                _telemetry.value = BeatTelemetry()
                bluetoothGatt.close()
                if (gatt == bluetoothGatt) gatt = null
            }
        }

        override fun onServicesDiscovered(bluetoothGatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _connectionState.value = "Service discovery failed"
                return
            }
            val service = bluetoothGatt.getService(serviceUuid)
            val characteristic = service?.getCharacteristic(telemetryUuid)
            if (characteristic == null) {
                _connectionState.value = "Simulator telemetry service not found"
                return
            }

            if (hasBlePermission()) {
                bluetoothGatt.setCharacteristicNotification(characteristic, true)
                val descriptor = characteristic.getDescriptor(cccdUuid)
                if (descriptor != null) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        bluetoothGatt.writeDescriptor(
                            descriptor,
                            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        bluetoothGatt.writeDescriptor(descriptor)
                    }
                } else {
                    _connectionState.value = "Connected; notification descriptor missing"
                }
            }
        }

        override fun onDescriptorWrite(
            bluetoothGatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            if (descriptor.uuid == cccdUuid) {
                _connectionState.value =
                    if (status == BluetoothGatt.GATT_SUCCESS) "Connected" else "Notification setup failed"
            }
        }

        @Deprecated("Compatibility callback for Android versions before API 33")
        override fun onCharacteristicChanged(
            bluetoothGatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == telemetryUuid) {
                parseTelemetry(characteristic.value)
            }
        }

        override fun onCharacteristicChanged(
            bluetoothGatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (characteristic.uuid == telemetryUuid) {
                parseTelemetry(value)
            }
        }
    }

    private fun parseTelemetry(bytes: ByteArray?) {
        if (bytes == null) return
        try {
            val json = JSONObject(bytes.toString(Charsets.UTF_8))
            if (json.optString("device") != "BEAT_ECU_SIM_V1" ||
                !json.optBoolean("simulationOnly", false)
            ) {
                _connectionState.value = "Rejected: not a simulator message"
                return
            }

            _telemetry.value = BeatTelemetry(
                rpm = json.optInt("rpm"),
                temperatureC = json.optDouble("temperatureC"),
                batteryV = json.optDouble("batteryV"),
                throttlePct = json.optDouble("throttlePct"),
                faultCode = json.optString("faultCode", "NONE"),
                faultStatus = json.optString("faultStatus", "NORMAL"),
                sequence = json.optLong("seq"),
                simulationOnly = true
            )
        } catch (_: Exception) {
            _connectionState.value = "Invalid simulator data"
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        stopScan()
        if (hasBlePermission()) gatt?.disconnect()
        gatt?.close()
        gatt = null
        _connectionState.value = "Disconnected"
        _deviceName.value = "No device"
        _telemetry.value = BeatTelemetry()
    }
}
