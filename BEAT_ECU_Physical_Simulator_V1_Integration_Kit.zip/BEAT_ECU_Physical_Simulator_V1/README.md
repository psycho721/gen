# BEAT ECU Physical Diagnostic Simulator V1

## Safety boundary
This is a standalone USB-powered demonstration simulator. It generates synthetic values.
Do not connect it to a Honda Beat, any motorcycle ECU, vehicle harness, engine sensor,
injector, ignition component, or vehicle power supply. It cannot diagnose a real motorcycle.

## Contents
- `esp32/BEAT_ECU_SIM_V1.ino`: ESP32 BLE simulator firmware.
- `android/.../BeatEcuBleManager.kt`: Android BLE scanner, connection and telemetry parser.
- `android/.../BleSimulatorPanel.kt`: Compose panel showing received sample data.
- `android/AndroidManifest.permissions.xml`: permissions to merge into your app manifest.
- `android/app/build.gradle.dependencies.txt`: required coroutine dependency.

## Part A — Upload firmware
1. Install Arduino IDE on your computer.
2. In Arduino IDE Preferences, add the Espressif ESP32 boards package URL from the official
   Espressif Arduino-ESP32 documentation.
3. Open Boards Manager and install `esp32 by Espressif Systems`.
4. Connect the ESP32 with a USB data cable.
5. Select the matching ESP32 board and serial port.
6. Open `esp32/BEAT_ECU_SIM_V1.ino` and upload it.
7. Open Serial Monitor at 115200 baud. The board should print that the simulator is ready.
8. Keep the ESP32 powered by USB. It advertises as `BEAT_ECU_SIM_V1`.
9. To toggle a virtual temperature fault for demonstration, type `F` in Serial Monitor.
   This only changes the generated demo message.

## Part B — Add Android files
1. Open your existing BEAT ECU Android project in Android Studio.
2. Copy `BeatEcuBleManager.kt` into package `com.beatecu.simulator.ble`.
3. Copy `BleSimulatorPanel.kt` into package `com.beatecu.simulator.ui`.
4. Merge the permissions from `AndroidManifest.permissions.xml` into the existing manifest.
   Do not replace the existing manifest or activity declaration.
5. Copy `BlePermissionButton.kt` into package `com.beatecu.simulator.ble`.
6. Add the coroutine dependency shown in `android/app/build.gradle.dependencies.txt`.
7. Sync Gradle.

## Part C — Runtime permissions
Use the included `BlePermissionButton` composable before enabling the Connect action. It requests:
- Android 12+ (API 31+): BLUETOOTH_SCAN and BLUETOOTH_CONNECT.
- Android 11 and lower: ACCESS_FINE_LOCATION at runtime.

Example: `BlePermissionButton { bleManager.startScan() }`. Also ensure Bluetooth is turned on.

## Part D — Add the panel to a Compose screen
Create the manager once in your Activity or a lifecycle-aware owner, not on every recomposition.
For a quick integration inside an existing composable, pass the manager down:

    BleSimulatorPanel(bleManager = yourBeatEcuBleManager)

Do not create a new manager each time the composable recomposes. A simple Activity-owned instance
is acceptable for a first test; production code should use a ViewModel and lifecycle-aware cleanup.

## BLE protocol
Device name: BEAT_ECU_SIM_V1
Service UUID: 7b6e0001-7d5a-4c2a-9f4b-2e8a00000001
Notify characteristic UUID: 7b6e0002-7d5a-4c2a-9f4b-2e8a00000001
Rate: 2 messages per second
Payload: UTF-8 JSON, below the default BLE notification payload limit.

## Test checklist
- [ ] ESP32 Serial Monitor prints simulator ready.
- [ ] Android runtime permissions are granted.
- [ ] Android Bluetooth is enabled.
- [ ] App finds `BEAT_ECU_SIM_V1`.
- [ ] Connection status changes to Connected.
- [ ] RPM, temperature, battery and throttle update.
- [ ] Typing F in Serial Monitor changes fault to SIM-T001.
- [ ] Disconnect returns the app to Disconnected.

## Important integration note
This kit is designed as an add-on to the existing BEAT ECU app. It does not include or overwrite
your original MainActivity or dashboard source because the exact current project source was not
provided in this turn. Add the panel to your existing Diagnostics or Sensors screen and connect
your app's telemetry state to `BeatEcuBleManager`.
