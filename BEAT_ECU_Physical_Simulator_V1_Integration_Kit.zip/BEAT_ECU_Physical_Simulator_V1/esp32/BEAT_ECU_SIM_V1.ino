/*
  BEAT ECU Physical Diagnostic Simulator V1
  SIMULATION ONLY. Do not connect to a motorcycle, vehicle ECU,
  engine sensor, injector, ignition system, or vehicle wiring.

  Board: ESP32 Dev Module / ESP32 DevKit
  Arduino IDE: install the Espressif ESP32 board package.
  BLE: uses the BLE library bundled with the ESP32 Arduino core.
*/

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <math.h>

static const char* DEVICE_NAME = "BEAT_ECU_SIM_V1";
static const char* SERVICE_UUID = "7b6e0001-7d5a-4c2a-9f4b-2e8a00000001";
static const char* TELEMETRY_UUID = "7b6e0002-7d5a-4c2a-9f4b-2e8a00000001";

BLECharacteristic* telemetryCharacteristic = nullptr;
bool clientConnected = false;

unsigned long lastSendMs = 0;
unsigned long startedMs = 0;
uint32_t sequenceNumber = 0;
bool simulateFault = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* server) override {
    clientConnected = true;
  }

  void onDisconnect(BLEServer* server) override {
    clientConnected = false;
    BLEDevice::startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  delay(300);
  startedMs = millis();

  BLEDevice::init(DEVICE_NAME);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* service = server->createService(SERVICE_UUID);

  telemetryCharacteristic = service->createCharacteristic(
    TELEMETRY_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );

  telemetryCharacteristic->addDescriptor(new BLE2902());
  telemetryCharacteristic->setValue(
    "{\"device\":\"BEAT_ECU_SIM_V1\",\"simulationOnly\":true,\"status\":\"READY\"}"
  );

  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println("BEAT ECU simulator ready. Waiting for BLE client.");
  Serial.println("Simulation only; no vehicle connection is supported.");
}

void loop() {
  // Serial command: type F and press Enter to toggle a virtual fault.
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'F' || c == 'f') {
      simulateFault = !simulateFault;
      Serial.printf("Virtual fault: %s\n", simulateFault ? "ON" : "OFF");
    }
  }

  const unsigned long now = millis();
  if (clientConnected && now - lastSendMs >= 500) {
    lastSendMs = now;
    sequenceNumber++;

    const float t = (now - startedMs) / 1000.0f;
    const int rpm = 900 + (int)(1100.0f + 900.0f * sinf(t * 0.45f));
    const float temperature = 72.0f + 8.0f * sinf(t * 0.12f);
    const float battery = 12.2f + 0.25f * sinf(t * 0.30f);
    const float throttle = 8.0f + 22.0f * (0.5f + 0.5f * sinf(t * 0.25f));

    const char* faultCode = simulateFault ? "SIM-T001" : "NONE";
    const char* faultMessage = simulateFault
      ? "SIMULATED_TEMPERATURE_WARNING"
      : "NORMAL";

    char payload[300];
    snprintf(
      payload, sizeof(payload),
      "{\"device\":\"BEAT_ECU_SIM_V1\","
      "\"simulationOnly\":true,"
      "\"seq\":%lu,"
      "\"rpm\":%d,"
      "\"temperatureC\":%.1f,"
      "\"batteryV\":%.2f,"
      "\"throttlePct\":%.1f,"
      "\"faultCode\":\"%s\","
      "\"faultStatus\":\"%s\"}",
      (unsigned long)sequenceNumber,
      rpm,
      temperature,
      battery,
      throttle,
      faultCode,
      faultMessage
    );

    telemetryCharacteristic->setValue((uint8_t*)payload, strlen(payload));
    telemetryCharacteristic->notify();

    Serial.println(payload);
  }

  delay(10);
}
